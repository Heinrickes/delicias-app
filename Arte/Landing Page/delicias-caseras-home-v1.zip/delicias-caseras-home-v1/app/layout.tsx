import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Delicias Caseras | Chocolatería fina artesanal",
  description:
    "Pequeños lujos cotidianos, elaborados a mano desde 2006. Chocolatería fina artesanal para regalar y disfrutar.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}
