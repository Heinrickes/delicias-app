"use client";

import Image from "next/image";
import { useState } from "react";

type IconProps = { size?: number; strokeWidth?: number; className?: string };

function Icon({ name, size = 22, strokeWidth = 1.5, className }: IconProps & { name: string }) {
  const common = {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    className,
    "aria-hidden": true,
  };
  const paths: Record<string, React.ReactNode> = {
    menu: <><path d="M4 7h16M4 12h16M4 17h16" /></>,
    close: <><path d="m6 6 12 12M18 6 6 18" /></>,
    search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-4-4" /></>,
    user: <><circle cx="12" cy="8" r="3.5" /><path d="M5.5 20c.7-4 3-6 6.5-6s5.8 2 6.5 6" /></>,
    bag: <><path d="M5 8h14l-1 12H6L5 8Z" /><path d="M9 9V6a3 3 0 0 1 6 0v3" /></>,
    arrow: <><path d="M5 12h14M14 7l5 5-5 5" /></>,
    play: <><circle cx="12" cy="12" r="9" /><path d="m10 8 6 4-6 4Z" /></>,
    leaf: <><path d="M19 4C11 4 5 8 5 14c0 3 2 5 5 5 6 0 9-7 9-15Z" /><path d="M5 20c2-5 6-8 11-11" /></>,
    hand: <><path d="M8 12V5a1.5 1.5 0 0 1 3 0v6" /><path d="M11 10V3.5a1.5 1.5 0 0 1 3 0V11" /><path d="M14 10V5a1.5 1.5 0 0 1 3 0v8" /><path d="M8 10 6.5 8.5a1.4 1.4 0 0 0-2 2L9 18c1 1.4 2.4 2 4 2 4 0 6-2.8 6-6v-4a1.5 1.5 0 0 0-3 0v2" /></>,
    gift: <><rect x="3" y="9" width="18" height="12" rx="1" /><path d="M12 9v12M3 13h18M7.5 9C5 9 4 7.7 4 6.3 4 5 5 4 6.4 4 9 4 12 9 12 9M16.5 9C19 9 20 7.7 20 6.3 20 5 19 4 17.6 4 15 4 12 9 12 9" /></>,
    heart: <><path d="M20.8 4.6a5.4 5.4 0 0 0-7.6 0L12 5.8l-1.2-1.2a5.4 5.4 0 0 0-7.6 7.6L12 21l8.8-8.8a5.4 5.4 0 0 0 0-7.6Z" /></>,
    plus: <><path d="M12 5v14M5 12h14" /></>,
    check: <><path d="m5 12 4 4L19 6" /></>,
    truck: <><path d="M3 6h11v10H3zM14 10h4l3 3v3h-7z" /><circle cx="7" cy="18" r="2" /><circle cx="18" cy="18" r="2" /></>,
    cocoa: <><path d="M12 3c4 2 7 5.5 7 9.5S16 20 12 21c-4-1-7-4.5-7-8.5S8 5 12 3Z" /><path d="M12 4v16M8 7c2 1.5 6 1.5 8 0M7 12c2.5 1.5 7.5 1.5 10 0M8 17c2 1.5 6 1.5 8 0" /></>,
  };
  return <svg {...common}>{paths[name]}</svg>;
}

const values = [
  { icon: "cocoa", title: "Ingredientes nobles", text: "Selección cuidadosa de materias primas y sabores de origen." },
  { icon: "hand", title: "Hecho a mano", text: "Cada pieza se elabora con dedicación, técnica y oficio artesanal." },
  { icon: "leaf", title: "Recetas originales", text: "Sabores propios, creados para sorprender y emocionar." },
  { icon: "gift", title: "Detalles que enamoran", text: "Presentaciones cuidadas que convierten cada momento en especial." },
  { icon: "heart", title: "Experiencias memorables", text: "Más que chocolate: pequeños recuerdos que perduran." },
];

const collections = [
  { name: "Bombones", description: "Pequeñas obras de arte.", image: "/images/bombones-porcelana.webp" },
  { name: "Alfajores", description: "Tradición que enamora.", image: "/images/alfajores-bandeja.webp" },
  { name: "Chocolates", description: "Textura, cacao y detalle.", image: "/images/alfajores-dorados.webp" },
  { name: "Ediciones especiales", description: "Creaciones únicas para regalar.", image: "/images/ritual-cafe.webp" },
];

const products = [
  { name: "Bombones artesanales", format: "Caja 9 unidades", price: "$12.900", image: "/images/bombones-porcelana.webp", badge: "Nuevo" },
  { name: "Alfajor clásico", format: "Caja 6 unidades", price: "$9.500", image: "/images/alfajores-bandeja.webp" },
  { name: "Alfajor cacao dorado", format: "Caja 6 unidades", price: "$11.900", image: "/images/alfajores-dorados.webp" },
  { name: "Colección sobremesa", format: "Selección artesanal", price: "$18.900", image: "/images/ritual-cafe.webp" },
];

export default function HomePage() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [cartCount, setCartCount] = useState(0);
  const [email, setEmail] = useState("");
  const [subscribed, setSubscribed] = useState(false);

  const addToCart = () => setCartCount((count) => count + 1);
  const subscribe = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!email.trim()) return;
    setSubscribed(true);
    setEmail("");
  };

  return (
    <div className="site-shell">
      <div className="announcement"><Icon name="truck" size={16} /> Envíos a todo Chile · Consulta cobertura y tiempos de entrega</div>

      <header className="header">
        <button className="icon-button mobile-menu-button" onClick={() => setMenuOpen(true)} aria-label="Abrir menú">
          <Icon name="menu" />
        </button>

        <a href="#inicio" className="brand" aria-label="Delicias Caseras, inicio">
          <Image src="/images/logo-oficial.png" alt="Delicias Caseras" width={180} height={180} priority />
        </a>

        <nav className="desktop-nav" aria-label="Navegación principal">
          <a href="#colecciones">Colecciones</a>
          <a href="#regalos">Regalos</a>
          <a href="#empresas">Empresas</a>
          <a href="#nosotros">Nosotros</a>
          <a href="#contacto">Contacto</a>
        </nav>

        <div className="header-actions">
          <button className="icon-button desktop-action" aria-label="Buscar"><Icon name="search" /></button>
          <button className="icon-button desktop-action" aria-label="Cuenta"><Icon name="user" /></button>
          <button className="icon-button cart-button" aria-label={`Carrito con ${cartCount} productos`}>
            <Icon name="bag" />
            <span>{cartCount}</span>
          </button>
        </div>
      </header>

      {menuOpen && (
        <div className="mobile-drawer" role="dialog" aria-modal="true" aria-label="Menú">
          <div className="drawer-header">
            <Image src="/images/logo-oficial.png" alt="Delicias Caseras" width={116} height={116} />
            <button className="icon-button" onClick={() => setMenuOpen(false)} aria-label="Cerrar menú"><Icon name="close" /></button>
          </div>
          <nav>
            {[["Colecciones", "#colecciones"], ["Regalos", "#regalos"], ["Empresas", "#empresas"], ["Nosotros", "#nosotros"], ["Contacto", "#contacto"]].map(([label, href]) => (
              <a key={label} href={href} onClick={() => setMenuOpen(false)}>{label}<Icon name="arrow" /></a>
            ))}
          </nav>
        </div>
      )}

      <main id="inicio">
        <section className="hero section-pad">
          <div className="hero-copy reveal">
            <p className="eyebrow">Hecho con amor · Desde 2006</p>
            <h1>Pequeños<br />lujos cotidianos.</h1>
            <div className="gold-line" />
            <p className="lead">Chocolatería fina artesanal diseñada para transformar momentos simples en experiencias memorables.</p>
            <div className="button-row">
              <a className="button primary" href="#colecciones">Descubrir colecciones</a>
              <a className="button secondary" href="#nosotros"><Icon name="play" size={19} /> Conocer nuestra historia</a>
            </div>
          </div>
          <div className="hero-media">
            <Image src="/images/hero-chocolates.webp" alt="Chocolates artesanales servidos en porcelana" fill priority sizes="(max-width: 760px) 100vw, 58vw" />
            <div className="hero-caption"><span>01</span> Elaboración artesanal</div>
          </div>
        </section>

        <section className="values" aria-label="Valores de Delicias Caseras">
          {values.map((value) => (
            <article key={value.title}>
              <Icon name={value.icon} size={30} strokeWidth={1.25} />
              <h2>{value.title}</h2>
              <p>{value.text}</p>
            </article>
          ))}
        </section>

        <section className="collections section-pad" id="colecciones">
          <div className="section-heading split-heading">
            <div>
              <p className="eyebrow">Colecciones destacadas</p>
              <h2>Descubre tu<br />próximo favorito.</h2>
            </div>
            <div>
              <p>Explora nuestras colecciones artesanales y encuentra el chocolate perfecto para cada ocasión.</p>
              <a className="text-link" href="#productos">Ver todos los productos <Icon name="arrow" size={17} /></a>
            </div>
          </div>
          <div className="collection-grid">
            {collections.map((collection, index) => (
              <a className={`collection-card card-${index + 1}`} href="#productos" key={collection.name}>
                <div className="collection-image"><Image src={collection.image} alt={collection.name} fill sizes="(max-width: 760px) 70vw, 25vw" /></div>
                <div className="collection-content">
                  <span>0{index + 1}</span>
                  <h3>{collection.name}</h3>
                  <p>{collection.description}</p>
                </div>
              </a>
            ))}
          </div>
        </section>

        <section className="story section-pad" id="nosotros">
          <div className="story-image"><Image src="/images/alfajores-bandeja.webp" alt="Elaboración artesanal de alfajores" fill sizes="(max-width: 760px) 100vw, 50vw" /></div>
          <div className="story-copy">
            <p className="eyebrow">Nuestra historia</p>
            <h2>Artesanos del chocolate desde 2006.</h2>
            <p>En Delicias Caseras, cada receta nace de la pasión por el chocolate y del compromiso con la excelencia artesanal. Seleccionamos ingredientes nobles y transformamos cada pieza en una experiencia cálida, honesta y memorable.</p>
            <div className="story-points">
              <span><Icon name="check" size={17} /> Cacao e ingredientes seleccionados</span>
              <span><Icon name="check" size={17} /> Elaboración en pequeñas partidas</span>
              <span><Icon name="check" size={17} /> Presentaciones hechas para regalar</span>
            </div>
            <a className="button primary" href="#contacto">Conoce más sobre nosotros</a>
          </div>
        </section>

        <section className="corporate section-pad" id="empresas">
          <div className="corporate-copy">
            <p className="eyebrow">Regalos corporativos</p>
            <h2>Regala experiencias que conectan.</h2>
            <p>Soluciones personalizadas para empresas, colaboradores y clientes. Cajas cuidadas, mensajes a medida y atención cercana para cada ocasión.</p>
            <a className="text-link light" href="#contacto">Conocer opciones para empresas <Icon name="arrow" size={17} /></a>
          </div>
          <div className="corporate-cards">
            <article><Icon name="gift" /><div><h3>Personalización</h3><p>Cajas, mensajes y selección de productos.</p></div></article>
            <article><Icon name="bag" /><div><h3>Volumen corporativo</h3><p>Alternativas para equipos y eventos.</p></div></article>
            <article><Icon name="heart" /><div><h3>Atención dedicada</h3><p>Acompañamiento desde la idea hasta la entrega.</p></div></article>
          </div>
        </section>

        <section className="products section-pad" id="productos">
          <div className="section-heading products-heading">
            <div><p className="eyebrow">Productos destacados</p><h2>Favoritos para compartir.</h2></div>
            <p>Contenido demostrativo para la Home V1. Los nombres, precios y formatos pueden editarse al conectar el catálogo real.</p>
          </div>
          <div className="product-grid">
            {products.map((product) => (
              <article className="product-card" key={product.name}>
                <div className="product-image">
                  {product.badge && <span className="badge">{product.badge}</span>}
                  <Image src={product.image} alt={product.name} fill sizes="(max-width: 760px) 70vw, 25vw" />
                </div>
                <div className="product-info">
                  <div><h3>{product.name}</h3><p>{product.format}</p><strong>{product.price}</strong></div>
                  <button onClick={addToCart} aria-label={`Agregar ${product.name} al carrito`}><Icon name="plus" size={18} /></button>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="testimonial section-pad">
          <div className="quote-mark">“</div>
          <blockquote>El chocolate más delicioso que he probado. Se nota la calidad y el amor en cada detalle.</blockquote>
          <cite>Carolina M. · Cliente</cite>
          <div className="testimonial-dots"><span className="active" /><span /><span /></div>
        </section>

        <section className="newsletter" id="contacto">
          <div>
            <p className="eyebrow">La sobremesa continúa</p>
            <h2>Recibe novedades, lanzamientos y momentos dulces.</h2>
          </div>
          {subscribed ? (
            <p className="success-message"><Icon name="check" /> Gracias por suscribirte. Pronto recibirás novedades de Delicias Caseras.</p>
          ) : (
            <form onSubmit={subscribe}>
              <label htmlFor="email" className="sr-only">Correo electrónico</label>
              <input id="email" type="email" placeholder="Tu correo electrónico" value={email} onChange={(event) => setEmail(event.target.value)} required />
              <button type="submit">Suscribirme</button>
            </form>
          )}
        </section>
      </main>

      <footer className="footer">
        <div className="footer-brand">
          <Image src="/images/logo-oficial.png" alt="Delicias Caseras" width={150} height={150} />
          <p>Chocolatería fina artesanal. Hecho con amor desde 2006.</p>
        </div>
        <div><h2>Explorar</h2><a href="#colecciones">Colecciones</a><a href="#productos">Productos</a><a href="#nosotros">Nuestra historia</a></div>
        <div id="regalos"><h2>Regalos</h2><a href="#empresas">Empresas</a><a href="#contacto">Fechas especiales</a><a href="#contacto">Cotizar</a></div>
        <div><h2>Contacto</h2><a href="mailto:hola@deliciascaseras.cl">hola@deliciascaseras.cl</a><a href="#">Instagram</a><a href="#">WhatsApp</a></div>
        <div className="footer-bottom"><span>© 2026 Delicias Caseras</span><span>Políticas · Términos · Privacidad</span></div>
      </footer>
    </div>
  );
}
