# Home V1 · Delicias Caseras

## Objetivo

Presentar a Delicias Caseras como una chocolatería fina artesanal, cálida y premium, guiando al visitante hacia las colecciones, la historia de marca y las opciones corporativas.

## Secciones implementadas

1. Barra informativa de envíos.
2. Header responsive con logo oficial, navegación, buscador, cuenta y carrito.
3. Hero: “Pequeños lujos cotidianos”.
4. Cinco valores de marca.
5. Colecciones destacadas.
6. Historia artesanal desde 2006.
7. Regalos corporativos.
8. Productos destacados con carrito demostrativo.
9. Testimonio.
10. Newsletter interactiva.
11. Footer completo.

## Comportamientos incluidos

- Menú móvil.
- Navegación por anclas.
- Contador de carrito demostrativo.
- Confirmación de suscripción.
- Carruseles horizontales naturales en mobile mediante scroll.
- Estados hover y transiciones suaves.
- Layout adaptativo para desktop, tablet y teléfono.

## Contenido pendiente antes de publicar

- Catálogo real, precios, stock y fotografías definitivas.
- Datos oficiales de contacto, WhatsApp y redes sociales.
- Política de despacho, privacidad y términos.
- Integración de ecommerce y medios de pago.
- Analítica, SEO avanzado y formularios conectados.
