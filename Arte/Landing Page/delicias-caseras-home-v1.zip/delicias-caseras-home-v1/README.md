# Delicias Caseras · Home V1

Prototipo funcional de la página de inicio de **Delicias Caseras**, construido con Next.js, TypeScript y Tailwind CSS 4.

## Incluye

- Logo oficial entregado por la marca.
- Home responsive para desktop, tablet y mobile.
- Menú móvil interactivo.
- Hero, valores, colecciones, historia, regalos corporativos, productos, testimonios, newsletter y footer.
- Contador de carrito demostrativo.
- Formulario de suscripción demostrativo.
- Fotografías reales suministradas durante el desarrollo.
- Variables cromáticas y estilos reutilizables.

## Ejecutar localmente

```bash
npm install
npm run dev
```

Abrir `http://localhost:3000`.

## Construcción de producción

```bash
npm run build
npm start
```

## Contenido demostrativo

Los precios, productos, enlaces, correo, Instagram y WhatsApp son placeholders de la V1. Deben reemplazarse con los datos comerciales definitivos y conectarse al catálogo real antes de publicar.

## Próxima fase recomendada

1. Aprobar Home V1.
2. Conectar catálogo y carrito.
3. Crear páginas Colecciones y Detalle de producto.
4. Implementar Regalos corporativos, Nosotros, Contacto y Checkout.
